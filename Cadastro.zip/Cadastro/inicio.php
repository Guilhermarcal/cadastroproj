<?php 
/* Chama conexão com banco */
require_once 'conexao.php';
$mysqli = conectar();
$sqlcad = "SELECT * FROM `cadastro` INNER JOIN `status_cli` ON `cadastro`.`id_status` = `status_cli`.`id_status` INNER JOIN `tipo_cli` ON `cadastro`.`id_tipo_cli` = `tipo_cli`.`id_tipo_cli` ORDER BY created DESC";

$resultcad = mysqli_query($mysqli, $sqlcad);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Tela inicial</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="webroot/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="webroot/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/css/util.css">
	<link rel="stylesheet" type="text/css" href="webroot/css/main.css">
	<link rel="stylesheet" type="text/css" href="webroot/css/gui.css">
<!--===============================================================================================-->

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">	
				<div style="margin-top: -100px;">
					<span class="tituloform"><b>Green Signal</b></span>
					<button class="botaocadastro">
							<a href="criar-cad1.php" style="color: white; font-size: 15px;">Cadastrar</a>
					</button>
				</div>
				<table width="100%" border="1" style="border-radius: 15px;">
					<thead >
						<tr >
							<th class="tamanhotable">Nome</th>
							<th class="tamanhotable">Idade</th>
							<th class="tamanhotable">Status</th>
							<th class="tamanhotable">Tipo Pessoa</th>
							<!-- <th class="tamanhotable">CPF</th> -->
							<!-- <th class="tamanhotable">CNPJ</th> -->
							<th class="tamanhotable" style="white-space: nowrap;">Criado em</th>
							<th class="tamanhotable">Modificado em</th>
							<th class="acoestable"><b>Ações</b></th>
						</tr>
					</thead>
					<tbody>
						<?php while($linha = mysqli_fetch_array($resultcad)): ?>
						<tr>
							<td class="tamanhotable"><?php echo $linha['nome']; ?></td>
							<td class="tamanhotable"><?php echo $linha['idade']; ?></td>
							<td class="tamanhotable">
							<?php if ($linha['status'] == 'ativo' or $linha['status'] == 'Ativo'){
								?>
									<div style="background-color: #AFE5E8;">
									<?php echo $linha['status']; ?>
									</div>
							<?php } 
							elseif ($linha['status'] == 'inativo' or $linha['status'] == 'Inativo') {
								?>
								<div style="background-color: #F89090;">
									<?php echo $linha['status']; ?>
								</div>
							 	
							<?php }
							elseif ($linha['status'] == 'ausente' or $linha['status'] == 'Ausente'){
							 	?>
							 	<div style="background-color: #E5AB5B;">
									<?php echo $linha['status']; ?>
								</div>
						<?php } ?>
							</td>
							<td class="tamanhotable"><?php echo $linha['tipo_pessoa']; ?></td>
							<td class="tamanhotable"><?php echo $linha['created']; ?></td>
							<td class="tamanhotable"><?php echo $linha['modified']; ?></td>
							<td class="acoesopc">
		                        <a href="form-edit.php?id=<?php echo $linha['id_cadastro'] ?>">Editar</a>
		                        <a href="form-ver.php?id=<?php echo $linha['id_cadastro'] ?>">Visualizar</a>
		                        <a href="delete.php?id=<?php echo $linha['id_cadastro'] ?>" onclick="return confirm('Tem certeza de que deseja remover?');">Remover</a>
                    		</td>
						</tr>
						<?php endwhile; ?>	

					</tbody>
				</table>
			</div>
		</div>
	</div>
	
	

	<script src="webroot/js/java.js"></script>
<!--===============================================================================================-->	
	<script src="webroot/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/bootstrap/js/popper.js"></script>
	<script src="webroot/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="webroot/js/main.js"></script>

</body>