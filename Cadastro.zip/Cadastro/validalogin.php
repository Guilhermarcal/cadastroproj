<?php

/* Chama conexão */
require_once 'conexao.php';

$mysqli = conectar();

/* Pega dados do form */ 

$username = isset($_POST['username']) ? $_POST['username'] : null;
$password = isset($_POST['password']) ? $_POST['password'] : null;

/* Executa select no banco - LOGIN  */

$sql = "SELECT * FROM login";
$result = mysqli_query($mysqli, $sql);
if (mysqli_num_rows($result) > 0){
	while ($dados = mysqli_fetch_array($result)) {
		if ($dados['username'] == $username && $dados['password'] == $password ) {
			header("Location: inicio.php");
			exit;
		}
	}
	header("Location: erro.php");
}




?>