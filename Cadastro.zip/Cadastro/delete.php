<?php
 
require_once 'conexao.php';
 
// pega o ID da URL
$id = isset($_GET['id']) ? $_GET['id'] : null;
 
// valida o ID
if (empty($id))
{
    echo "ID não informado";
    exit;
}
 
// remove do banco
$mysqli = conectar();
$sqlsta = "DELETE FROM status_cli WHERE id_status = (SELECT id_status FROM cadastro WHERE id_cadastro = $id)";
$resultsta = mysqli_query($mysqli, $sqlsta) or die ("Erro sql");
/*-------------------------*/
$sqltipo = "DELETE FROM tipo_cli WHERE id_tipo_cli = (SELECT id_tipo_cli FROM cadastro WHERE id_cadastro = $id)";
$resulttipo = mysqli_query($mysqli, $sqltipo) or die ("Erro sql1");
/*-------------------------*/
$sqldados = "DELETE FROM dados_cli WHERE id_dados = (SELECT id_dados FROM cadastro WHERE id_cadastro = $id)";
$resultdados = mysqli_query($mysqli, $sqldados) or die ("Erro sql2");

$sql = "DELETE FROM cadastro WHERE id_cadastro = $id";
$resultcad = mysqli_query($mysqli, $sql) or die ("Erro sql3");


/*-----------------------------------*/
header('Location: inicio.php');

