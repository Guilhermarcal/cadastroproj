<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Erro ao logar</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="webroot/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="webroot/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/css/util.css">
	<link rel="stylesheet" type="text/css" href="webroot/css/main.css">
<!--===============================================================================================-->

		
	<!-- Aqui chama o arquivo para função validação  -->
	<!-- Aqui chama o arquivo para função validação  -->
	<!-- Aqui chama o arquivo para função validação  -->
	<link src="validalogin.php"></link>
	

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">	
				<div>
					<h1 style="padding-bottom: 150px;padding-left: 100px;">Usuario ou senha incorreto!</h1>
					<script type="text/javascript">
						setTimeout(alerta, 1000);

						function alerta(){
						window.location.href = "index.php";
						}
					</script>
				</div>
			</div>
		</div>
	</div>
	
	

	<script src="webroot/js/java.js"></script>
<!--===============================================================================================-->	
	<script src="webroot/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/bootstrap/js/popper.js"></script>
	<script src="webroot/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="webroot/js/main.js"></script>

</body>

	
	
