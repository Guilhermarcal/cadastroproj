<?php 
/* Chama conexão */
require_once 'conexao.php';


/* email */
$email = isset($_POST['email']) ? $_POST['email'] : null;
/* telefone */
$telefone = isset($_POST['telefone']) ? $_POST['telefone'] : null;
/* bairro */
$bairro = isset($_POST['bairro']) ? $_POST['bairro'] : null;
/* idade */
$idade = isset($_POST['idade']) ? $_POST['idade'] : null;
/* cpf */
$cpf = isset($_POST['cpf']) ? $_POST['cpf'] : null;
/* cnpj */ 
$cnpj = isset($_POST['cnpj']) ? $_POST['cnpj'] : null;
/* tempocli */
$tempocli = isset($_POST['tempocli']) ? $_POST['tempocli'] : null;
/* Tipo */
$tipo = isset($_POST['tipopessoa']) ? $_POST['tipopessoa'] : null;
/* status */
$status = isset($_POST['status']) ? $_POST['status'] : null;
/* nome */
$nomeusu = isset($_POST['nomeusu']) ? $_POST['nomeusu'] : null;
/* date("d/m/Y H:i:s") */
date_default_timezone_set('America/Sao_Paulo');
$modificado = date("Y-m-d H:i:s");

/* Arruma data de acordo com o banco */
$idodate = dateConvert($tempocli);

/*---------------------------------------------*/
$mysqli2 = conectar();

$sqlstatus = "INSERT INTO status_cli(status,tempo_cli) VALUES ('$status','$idodate')";
$resultstatus = mysqli_query($mysqli2, $sqlstatus) or die ("Por favor volte e digite o campo data corretamente. Ex: XX/XX/XXXX");
/*---------------------------------------------*/
$mysqli = conectar();

$sqldados = "INSERT INTO dados_cli(email,bairro,telefone) VALUES ('$email','$bairro','$telefone')";
$resultdados = mysqli_query($mysqli, $sqldados) or die ("Erro sql2");
/*---------------------------------------------*/
$mysqli3 = conectar();

$sqltipo = "INSERT INTO tipo_cli(tipo_pessoa, cpf, cnpj) VALUES ('$tipo','$cpf','$cnpj')";
$resulttipo = mysqli_query($mysqli3, $sqltipo) or die ("Erro sql4");
/*---------------------------------------------*/
$mysqli4 = conectar();

$select = "SELECT id_status from status_cli";
$resultado = mysqli_query($mysqli4, $select);

while($linha = mysqli_fetch_array($resultado)){
	$id_sta = $linha['id_status'];
}

$select2 = "SELECT id_tipo_cli from tipo_cli";
$resultado2 = mysqli_query($mysqli4, $select2);
while($linha2 = mysqli_fetch_array($resultado2)){
	$id_tip = $linha2['id_tipo_cli'];
}

$select3 = "SELECT id_dados from dados_cli";
$resultado3 = mysqli_query($mysqli4, $select3);
while($linha3 = mysqli_fetch_array($resultado3)){
	$id_dad = $linha3['id_dados'];
}
	
$sql = "INSERT INTO cadastro(nome,id_tipo_cli,id_status,id_dados,idade,modified) VALUES ('$nomeusu','$id_tip','$id_sta','$id_dad','$idade','$modificado')";
$result = mysqli_query($mysqli4, $sql) or die ("Erro sql");

/*---------------------------------------------*/

/*---------------------------------------------*/
header("Location: inicio.php");
	exit;

?>

?>