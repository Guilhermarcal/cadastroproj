/* =========================
* Login para pagina verde
========================== */
function Login1(){

var username=document.login.username.value;
var password=document.login.password.value;
var arrayusu = Array();
arrayusu = ["p618784","p015516","p060350","p015435","p053914","p014692"];
var arraysenha = Array();
arraysenha = ["p618784","p015516","p060350","p015435","p053914","p014692"];
var arraynome = Array();
arraynome = ["Guilherme M.","M. Goretti","Rômulo","M. Fatima","Ederson C.","Tania M."];


for(var i = 0; i < arrayusu.length; i++ ){
	if(arrayusu[i] == username && arraysenha[i] == password){ alert("Bem vindo: " + arraynome[i] );
    <?php echo $this->Form->end('Login', array('id' => 'Passagem/index2.ctp')); ?>
    ;close();}
    if(arrayusu[i] == username && arraysenha[i] != password){ alert("Senha incorreta ou inválida!");window.open('index.ctp');close();}
    if(arrayusu[i] != username){ alert("Usúario não encontrado! Digite novamente ou realize um cadastro");window.open('index.ctp');close();}
}


/*
if (username=="p618784" && password=="p618784") { alert("Bem vindo Guilherme M." );window.open('ManualVerm.html'); done=1;close(); }
if (username=="p015516" && password=="p015516") { alert("Bem vinda M. Goretti" ); window.open('ManualVerm.html'); done=1;close(); }
if (username=="p060350" && password=="p060350") { alert("Bem vindo Rômulo" ); window.open('ManualVerm.html'); done=1;close(); }
if (username=="p015435" && password=="p015435") { alert("Bem vinda M. Fatima" ); window.open('ManualVerm.html'); done=1;close(); }
if (username=="p053914" && password=="p053914") { alert("Bem vindo Ederson C." ); window.open('ManualVerm.html'); done=1; close();}
if (username=="p014692" && password=="p014692") { alert("Bem vinda Tania M." );window.open('ManualVerm.html'); done=1;close(); }

if (done==0) { alert("Senha ou Usuário inválido.");}
*/
}
/* =========================
* Login para pagina vermelha
========================== */
function Login2(){

var username=document.login.username.value;
var password=document.login.password.value;
var arrayusu = Array();
arrayusu = ["p618784","p015516","p060350","p015435","p053914","p014692"];
var arraysenha = Array();
arraysenha = ["p618784","p015516","p060350","p015435","p053914","p014692"];
var arraynome = Array();
arraynome = ["Guilherme M.","M. Goretti","Rômulo","M. Fatima","Ederson C.","Tania M."];


for(var i = 0; i < arrayusu.length; i++ ){
	if(arrayusu[i] == username && arraysenha[i] == password){ alert("Bem vindo: " + arraynome[i] );['action' => 'index2'];close();}
    if(arrayusu[i] == username && arraysenha[i] != password){ alert("Senha incorreta ou inválida!");window.open('index.ctp');close();}
    if(arrayusu[i] != username){ alert("Usúario não encontrado! Digite novamente ou realize um cadastro");window.open('index.ctp');close();}
}


/*
if (username=="p618784" && password=="p618784") { alert("Bem vindo Guilherme M." );window.open('ManualVerm.html'); done=1;close(); }
if (username=="p015516" && password=="p015516") { alert("Bem vinda M. Goretti" ); window.open('ManualVerm.html'); done=1;close(); }
if (username=="p060350" && password=="p060350") { alert("Bem vindo Rômulo" ); window.open('ManualVerm.html'); done=1;close(); }
if (username=="p015435" && password=="p015435") { alert("Bem vinda M. Fatima" ); window.open('ManualVerm.html'); done=1;close(); }
if (username=="p053914" && password=="p053914") { alert("Bem vindo Ederson C." ); window.open('ManualVerm.html'); done=1; close();}
if (username=="p014692" && password=="p014692") { alert("Bem vinda Tania M." );window.open('ManualVerm.html'); done=1;close(); }

if (done==0) { alert("Senha ou Usuário inválido.");}
*/
}

/************
 * Botão Load
 ************/
 function checaRadio(){
        var radio = document.getElementsByTagName("input");
        var done = 0;
        for(i=0; i<radio.length; i++){
            if (radio[i].getAttribute("type") == "radio" && radio[i].checked == true){
                
                if(radio[i].value == 'LVerd'){
                return Login1();
                }
                if(radio[i].value == 'LVerm'){
                return Login2();
                }
            close();
            }


            }
            for(i=0; i<radio.length; i++){
            if(radio[i].getAttribute("type") == "radio" && radio[i].checked == false && done != 1){
            	alert("Por favor, selecione uma opção!!!!");
            	done++;
            }
            }
       }