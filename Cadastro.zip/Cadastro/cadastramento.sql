-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 07-Jan-2019 às 09:11
-- Versão do servidor: 5.7.23
-- versão do PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cadastramento`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro`
--

DROP TABLE IF EXISTS `cadastro`;
CREATE TABLE IF NOT EXISTS `cadastro` (
  `id_cadastro` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_cli` int(11) NOT NULL,
  `id_status` int(11) NOT NULL,
  `id_dados` int(11) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `idade` int(11) NOT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_cadastro`),
  KEY `FK_id_tipo_cli` (`id_tipo_cli`),
  KEY `FK_id_status` (`id_status`),
  KEY `FK_id_dados` (`id_dados`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `dados_cli`
--

DROP TABLE IF EXISTS `dados_cli`;
CREATE TABLE IF NOT EXISTS `dados_cli` (
  `id_dados` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `bairro` varchar(60) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  PRIMARY KEY (`id_dados`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id_login` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  PRIMARY KEY (`id_login`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login` (`id_login`, `username`, `password`) VALUES
(1, 'Admingreen', 'Admingreen');

-- --------------------------------------------------------

--
-- Estrutura da tabela `status_cli`
--

DROP TABLE IF EXISTS `status_cli`;
CREATE TABLE IF NOT EXISTS `status_cli` (
  `id_status` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL,
  `tempo_cli` date NOT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_cli`
--

DROP TABLE IF EXISTS `tipo_cli`;
CREATE TABLE IF NOT EXISTS `tipo_cli` (
  `id_tipo_cli` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_pessoa` varchar(60) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `cnpj` varchar(30) NOT NULL,
  PRIMARY KEY (`id_tipo_cli`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
