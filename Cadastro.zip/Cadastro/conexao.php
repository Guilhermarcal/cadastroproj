<?php

function conectar(){

	// dados de conexão
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$db   = 'cadastramento';

	// Conecta-se ao banco de dados MySQL

	try {
		$mysqli = mysqli_connect($host, $user, $pass,$db);
		$mysqli->set_charset("utf8");
		return $mysqli;
	}
	 // Caso algo tenha dado errado, exibe uma mensagem de erro
	catch (Exception $e) {
		return "Ocorreu um erro ao conectar" . $e->getMessage();
	}

}
function dateConvert($date)
{
    if ( ! strstr( $date, '/' ) )
    {
        // $date está no formato ISO (yyyy-mm-dd) e deve ser convertida
        // para dd/mm/yyyy
        sscanf($date, '%d-%d-%d', $y, $m, $d);
        return sprintf('%02d/%02d/%04d', $d, $m, $y);
    }
    else
    {
        // $date está no formato brasileiro e deve ser convertida para ISO
        sscanf($date, '%d/%d/%d', $d, $m, $y);
        return sprintf('%04d-%02d-%02d', $y, $m, $d);
    }
 
    return false;
}
function dateconvert2($date){

	if (strstr($date,'-')) {
		sscanf($date, '%d-%d-%d', $d, $m, $y);
		return sprintf('%04d-%02d-%02d', $y, $m, $d);
	}
}


?>
