<?php
 
require_once 'conexao.php';

/* id */
$id = isset($_POST['id']) ? $_POST['id'] : null; 
/* email */
$email = isset($_POST['email']) ? $_POST['email'] : null;
/* telefone */
$telefone = isset($_POST['telefone']) ? $_POST['telefone'] : null;
/* bairro */
$bairro = isset($_POST['bairro']) ? $_POST['bairro'] : null;
/* idade */
$idade = isset($_POST['idade']) ? $_POST['idade'] : null;
/* cpf */
$cpf = isset($_POST['cpf']) ? $_POST['cpf'] : null;
/* cnpj */ 
$cnpj = isset($_POST['cnpj']) ? $_POST['cnpj'] : null;
/* tempocli */
$tempocli = isset($_POST['tempocli']) ? $_POST['tempocli'] : null;
/* Tipo */
$tipo = isset($_POST['tipopessoa']) ? $_POST['tipopessoa'] : null;
/* status */
$status = isset($_POST['status']) ? $_POST['status'] : null;
/* nome */
$nomeusu = isset($_POST['nomeusu']) ? $_POST['nomeusu'] : null;
/* date("d/m/Y H:i:s") */
date_default_timezone_set('America/Sao_Paulo');
$modificado = date("Y-m-d H:i:s");

 
// atualiza o banco
$mysqli = conectar();
$sql = "UPDATE cadastro SET nome = '$nomeusu', idade = '$idade', modified = '$modificado' WHERE id_cadastro = '$id'";
$result = mysqli_query($mysqli, $sql) or die ("Erro sql");
/*---------------------------------------------*/
$mysqli2 = conectar();
$sql2 = "UPDATE dados_cli SET email = '$email', bairro = '$bairro', telefone = '$telefone' WHERE id_dados = (SELECT id_dados FROM cadastro WHERE id_cadastro = $id)";
$result2 = mysqli_query($mysqli2, $sql2) or die ("Erro sql2");
/*---------------------------------------------*/
$mysqli3 = conectar();
$sql3 = "UPDATE status_cli SET status = '$status', tempo_cli = '$tempocli' WHERE id_status = (SELECT id_status FROM cadastro WHERE id_cadastro = $id)";
$result3 = mysqli_query($mysqli3, $sql3) or die ("Erro sql3 -> $tempocli");
/*---------------------------------------------*/
$mysqli4 = conectar();
$sql4 = "UPDATE tipo_cli SET tipo_pessoa = '$tipo', cpf = '$cpf', cnpj = '$cnpj' WHERE id_tipo_cli = (SELECT id_tipo_cli FROM cadastro WHERE id_cadastro = $id)";
$result4 = mysqli_query($mysqli4, $sql4) or die ("Erro sql4");

/*---------------------------------------------*/

/*---------------------------------------------*/
header("Location: inicio.php");
	exit;

?>

