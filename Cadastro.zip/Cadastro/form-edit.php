<?php
require 'conexao.php';
 
// pega o ID da URL
$id = isset($_GET['id']) ? (int) $_GET['id'] : null;
 
// valida o ID
if (empty($id))
{
    echo "ID para alteração não definido";
    exit;
}
 
// busca os dados du usuário a ser editado
$mysqli= conectar();
$sqlcad = "SELECT * FROM cadastro, status_cli, tipo_cli, dados_cli WHERE `cadastro`.`id_status` = `status_cli`.`id_status` and `cadastro`.`id_tipo_cli` = `tipo_cli`.`id_tipo_cli` and `cadastro`.`id_dados` = `dados_cli`.`id_dados` and id_cadastro = '$id'";

$resultcad = mysqli_query($mysqli, $sqlcad);
$linha = mysqli_fetch_array($resultcad);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Tela inicial</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="webroot/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="webroot/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="webroot/css/util.css">
	<link rel="stylesheet" type="text/css" href="webroot/css/main.css">
	<link rel="stylesheet" type="text/css" href="webroot/css/gui.css">
<!--===============================================================================================-->

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">	
				<form name="add_form" method="post"
				action="edit.php">
					<h1 style="margin-top: -100px;color: #36CB29">Formulario de cadastramento</h1>
					<hr/>
					<br><br>
					<h3>Dados pessoais</h3>
					<hr/>
					<br>
					<table>
						<tbody>
							<tr>
								<td style="width: 50%">
									<label for="nomeusu">Nome</label>
									<br>
									<input class="inputcad" type="text" name="nomeusu" id="nomeusu" placeholder="Digite seu nome" required value="<?php echo $linha['nome'] ?>">
								</td>
								<td style="width: 100%;padding-left: 20px">
									<label for="email">Email</label>
									<br>
									<input class="inputcad" type="email" name="email" id="email" placeholder="email@gmail.com" required value="<?php echo $linha['email'] ?>">
								</td>
							</tr>

							<tr>
								<td style="width: 50%"><br><br>
									<label for="telefone">Telefone</label>
									<br>
									<input class="inputcad" type="tel" name="telefone" id="telefone" placeholder="(xx)xxxxx-xxxx" required value="<?php echo $linha['telefone'] ?>">
								</td>
								<td style="width: 100%;padding-left: 20px"><br><br>
									<label for="bairro">Bairro</label>
									<br>
									<input class="inputcad" type="text" name="bairro" id="bairro" placeholder="Digite seu bairro" required value="<?php echo $linha['bairro'] ?>">
								</td>
							</tr>
							<tr>
								<td style="width: 50%"><br><br>
									<label for="idade">Idade</label>
									<br>
									<input class="inputcad" type="number" name="idade" id="idade" placeholder="Digite sua idade" required value="<?php echo $linha['idade'] ?>">
								</td>
								<td style="width: 100%;padding-left: 20px"><br><br>
									<label for="cpf">CPF</label>
									<br>
									<input class="inputcad" type="text" name="cpf" id="cpf" placeholder="xxx.xxx.xxx-xx" minlength="11" required value="<?php echo $linha['cpf'] ?>">
								</td>								
							</tr>
							<tr>
								<td style="width: 50%"><br><br>
									<label for="cnpj">CNPJ - Caso tenha</label>
									<br>
									<input class="inputcad" type="text" name="cnpj" id="cnpj" placeholder="Digite o CNPJ" value="<?php echo $linha['cnpj'] ?>">
								</td>
								<td style="width: 100%;padding-left: 20px"><br><br>
									<label for="tempocli">Cliente desde</label>
									<br>
									<input class="inputcad" type="text" name="tempocli" id="tempocli" placeholder="Cliente desde " required value="<?php echo $linha['tempo_cli'] ?>">
								</td>								
							</tr>
							<tr>
								<td style="width: 50%"><br><br>
									<label><b>Tipo de pessoa</b></label>
									<br><br>
									<input class="inputcad" type="text" name="tipopessoa" id="tipopessoa" placeholder="Cliente desde " required value="<?php echo $linha['tipo_pessoa'] ?>">
								</td>
								<td style="width: 100%;padding-left: 20px"><br><br>
									<label for="status"><b>Status</b></label>
									<br><br>
									<input class="inputcad" type="text" name="status" id="status" placeholder="Cliente desde " required value="<?php echo $linha['status'] ?>">
								</td>
							</tr>
						</tbody>
					</table>
					<br><br><br>

					<input type="hidden" name="id" value="<?php echo $id ?>">

					<button class="botaovoltar">
						<a href="inicio.php" style="color: #fff;font-size: 15px;">Voltar</a>
					</button>
					
					<button class="botaoavanco" style="margin-left: 80px; ">
						avançar
					</button>
				</form>

			</div>
		</div>
	</div>
	
	<script src="webroot/js/java.js"></script>
<!--===============================================================================================-->	
	<script src="webroot/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/bootstrap/js/popper.js"></script>
	<script src="webroot/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="webroot/vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="webroot/js/main.js"></script>

</body>