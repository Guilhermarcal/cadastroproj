<?php 
/* Chama conexão */
require_once 'conexao.php';

/* nome */
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
/* email */
$email = isset($_POST['email']) ? $_POST['email'] : null;
/* telefone */
$telefone = isset($_POST['telefone']) ? $_POST['telefone'] : null;
/* bairro */
$bairro = isset($_POST['bairro']) ? $_POST['bairro'] : null;
/* idade */
$idade = isset($_POST['idade']) ? $_POST['idade'] : null;
/* Tipo */
$tipo = isset($_POST['tipopessoa']) ? $_POST['tipopessoa'] : null;
/* cpf */
$cpf = isset($_POST['cpf']) ? $_POST['cpf'] : null;
/* cnpj */ 
$cnpj = isset($_POST['cnpj']) ? $_POST['cnpj'] : null;
/* tempocli */
$tempocli = isset($_POST['tempocli']) ? $_POST['tempocli'] : null;
/* status */
$status = isset($_POST['status']) ? $_POST['status'] : null;
/* date("d/m/Y H:i:s") */
$modificado = date("Y-m-d H:i:s");


/*---------------------------------------------*/
$mysqli = conectar();

$sqldados = "INSERT INTO dados_cli(email,bairro,telefone) VALUES ('$email','$bairro','$telefone')";
$resultdados = mysqli_query($mysqli, $sqldados) or die ("Erro sql2");
/*---------------------------------------------*/
$mysqli2 = conectar();

$sqlstatus = "INSERT INTO status_cli(status,tempo_cli) VALUES ('$status','$tempocli')";
$resultstatus = mysqli_query($mysqli2, $sqlstatus) or die ("Erro sql3");
/*---------------------------------------------*/
$mysqli3 = conectar();

$sqltipo = "INSERT INTO tipo_cli(tipo_pessoa, cpf, cnpj) VALUES ('$tipo','$cpf','$cnpj')";
$resulttipo = mysqli_query($mysqli3, $sqltipo) or die ("Erro sqç4");
/*---------------------------------------------*/
$mysqli4 = conectar();

$sql = "INSERT INTO cadastro(nome,idade,modified) VALUES ('$nome','$idade','$modificado')";
$result = mysqli_query($mysqli4, $sql) or die ("Erro sql");
/*---------------------------------------------*/

/*---------------------------------------------*/
header("Location: inicio.php");
	exit;

?>